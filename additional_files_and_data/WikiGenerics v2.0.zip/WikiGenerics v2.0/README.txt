=== WikiGenerics corpus ===

Version 2.0
September 2015

This corpus is freely available. Please cite one of the papers below when using it
(please cite the one(s) most relevant to your work).

This website has more information on our project:
http://www.coli.uni-saarland.de/projects/sitent

If you have any questions, please contact Annemarie Friedrich (afried@coli.uni-saarland.de).


== Format ==

* Columns in the CSV files are separated by tabs.
* The column names are gold_NP, gold_Cl, gold_Cl+NP and gold_clausal_aspect for the gold standard
  created via majority voting.
  A-NP, B-Cl etc. are the annotations given by the three annotators A, B and C.


== Annotation Scheme and guidelines ==

The annotation guidelines can be found in the Situation Entities annotation manual (see web site above).
* NP: genericity of main referent, GENERIC or NON-GENERIC
* Cl: genericity of clause (any GENERIC SENTENCES with a generic main referent)
* Cl+NP: combination of the two labels above, first the Cl (GEN or NON-GEN), then the main referent's
  (subject's) label (gen or non-gen).
* For the three above labels, please see the ACL 2015 paper.
* clausal_aspect: EPISODIC, STATIC or HABITUAL (see EMNLP 2015 paper).


== References ==

Annemarie Friedrich, Alexis Palmer, Melissa Peate Sørensen and Manfred Pinkal: Annotating genericity: a survey, a scheme, and a corpus. June 2015. In Proceedings of the 9th Linguistic Annotation Workshop (LAW IX). Denver, Colorado, US.

Annemarie Friedrich and Manfred Pinkal: Discourse-sensitive Automatic Identification of Generic Expressions. August 2015. In Proceedings of the 53rd Annual Meeting of the Association for Computational Linguistics (ACL). Beijing, China.

Annemarie Friedrich and Manfred Pinkal: Automatic recognition of habituals: a three-way classification of clausal aspect. September 2015. In Proceedings of the 2015 Conference on Empirical Methods in Natural Language Processing (EMNLP). Lisbon, Portugal.
